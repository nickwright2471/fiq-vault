Welcome to Fi-q!

*CAUTION*
IF YOU LEAVE THE GAME WITHOUT SAVING, YOU WILL LOSE ALL PROGRESS, TEAM SCORES, AND RECORDED DATA. BE MINDFUL BEFORE CLICKING YOUR BROWSER'S BACK BUTTON OR REFRESH BUTTON.


ADMIN INSTRUCTIONS:

Online 

1. Click the logo or program name to open the "admin-panel"
2. Swap logos
  a. Find url of desired logo
  b. Paste url into input field 
3. Choose App Name
4. Click "save changes"



Offline

1. Click the logo or program name to open the "admin-panel" or open "admin-panel.html"
2. Swap logos
  a. Access the "customize" folder that contains the image.
  b. place desired image file into the "customize" folder. Logo MUST BE NAMED "logo.png" to work.
3. Choose App Name
4. Click "save changes"





USER INSTRUCTIONS:
1. Choose number of teams
2. Choose the board’s grid layout (number of questions that should be displayed)
3. Click “Start”. Returning users click last saved game. 
4. User selects a number (ex: Saving and Investing for 300)
   -User decides on answer
5. Click “Show Answer”
   -If user is correct, click “+”
   -If user is incorrect, click “-”
6. Click “continue” or “back to board”
7. Click save icon if saving is desired.


